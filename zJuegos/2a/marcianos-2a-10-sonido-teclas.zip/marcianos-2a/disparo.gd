extends Area2D

var velocidad = 150
var escena_explosion

func _ready() -> void:
	escena_explosion = load("res://explosion.tscn")

func _process(delta: float) -> void:
	position.y -= velocidad * delta

func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("enemigos"):
		get_parent().get_node("SonidoExplosion").play()
		var explosion = escena_explosion.instantiate()
		explosion.position = position
		get_parent().add_child(explosion)
		explosion.emitting = true
		area.queue_free()
		queue_free()
