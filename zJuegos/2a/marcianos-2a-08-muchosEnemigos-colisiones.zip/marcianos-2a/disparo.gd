extends Area2D

var velocidad = 150

func _ready() -> void:
	pass # Replace with function body.

func _process(delta: float) -> void:
	position.y -= velocidad * delta

func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("enemigos"):
		area.queue_free()
		queue_free()
