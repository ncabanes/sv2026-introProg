extends Area2D

var velocidad = 150

func _ready() -> void:
	pass # Replace with function body.

func _process(delta: float) -> void:
	position.y -= velocidad * delta
