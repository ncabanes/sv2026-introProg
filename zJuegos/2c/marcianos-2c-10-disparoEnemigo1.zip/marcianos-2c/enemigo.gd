extends Area2D

var velocidad = 300
var escena_explosion

func _ready() -> void:
	escena_explosion = load("res://explosion.tscn")

func _process(delta: float) -> void:
	position.x += velocidad * delta
	if position.x > 1180 or position.x < 100:
		velocidad = -velocidad
		


func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("nave"):
		get_tree().change_scene_to_file("res://bienvenida.tscn")
	elif area.is_in_group("disparos"):
		var explosion = escena_explosion.instantiate()
		explosion.position = position
		get_parent().add_child(explosion)
		explosion.emitting = true
		area.queue_free()
		queue_free()
