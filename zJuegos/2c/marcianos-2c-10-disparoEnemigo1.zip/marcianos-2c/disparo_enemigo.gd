extends Area2D

var velocidad = 200

func _process(delta: float) -> void:
	position.y += velocidad * delta
