extends Node2D

var escena_disparo_enemigo

func _ready() -> void:
	escena_disparo_enemigo = load("res://disparo_enemigo.tscn")


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_temporizador_disparo_enemigos_timeout() -> void:
	var disparo = escena_disparo_enemigo.instantiate()
	disparo.position.x = 640
	add_child(disparo)
