extends Area2D

var velocidad = 600
var escena_disparo

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	position.y = 580
	escena_disparo = load("res://disparo.tscn")
	add_to_group("nave")


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if Input.is_action_pressed("ui_right") and position.x < 1200:
		position.x += velocidad * delta
	if Input.is_action_pressed("ui_left") and position.x > 80:
		position.x -= velocidad * delta
	if Input.is_action_pressed("ui_up") and position.y > 40:
		position.y -= velocidad * delta
	if Input.is_action_pressed("ui_down") and position.y < 680:
		position.y += velocidad * delta
	if Input.is_action_just_pressed("ui_accept"):
		var disparo = escena_disparo.instantiate()
		disparo.position = position
		get_parent().add_child(disparo)
		
		
		
