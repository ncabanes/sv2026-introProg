extends Area2D

var velocidad = 150

func _ready() -> void:
	add_to_group("disparos")

func _process(delta: float) -> void:
	position.y -= velocidad * delta
