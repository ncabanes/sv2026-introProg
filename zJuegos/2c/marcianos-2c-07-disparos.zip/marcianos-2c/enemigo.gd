extends Area2D

var velocidad = 300

func _ready() -> void:
	pass # Replace with function body.

func _process(delta: float) -> void:
	position.x += velocidad * delta
	if position.x > 1180 or position.x < 100:
		velocidad = -velocidad
		


func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("nave"):
		get_tree().change_scene_to_file("res://bienvenida.tscn")
	elif area.is_in_group("disparos"):
		area.queue_free()
		queue_free()
